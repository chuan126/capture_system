# 前端全功能测试数据

本测试包适用于当前的任务持久化、数据回放、任务删除、TXT 导出和 PDF 汇总版本。

## 重要说明

所有净空高度、RTK 坐标、时间、状态和质量指标均为模拟数据，不得作为现场检测记录或正式报告。

当前程序只允许 `data_origin=recorded` 的完整任务进入正式导出。为了验证导出按钮和文件生成链路，任务 02 和任务 03 的该字段设置为 `recorded`。两个任务的隧道编号、名称和版本字段均带有 TEST 或模拟标识。

## 测试任务

| 序号 | 隧道编号 | 状态 | 回放 | TXT | PDF 汇总 |
|---|---|---|---|---|---|
| 01 | TEST-PENDING-001 | 待执行 | 空状态 | 禁用 | 不纳入 |
| 02 | TEST-EXPORT-L | 已停止 | 3000 个 50 Hz 样本，含三段断线和一次暂停 | 可导出 | 纳入 |
| 03 | TEST-EXPORT-R | 已停止 | 2400 个 50 Hz 样本，含三段断线 | 可导出 | 纳入 |
| 04 | TEST-INTERRUPTED | 异常中断 | 1200 个样本，无出口 RTK | 禁用 | 不纳入 |
| 05 | TEST-FAILED-001 | 失败 | 空状态 | 禁用 | 不纳入 |

安装后新建任务的显示序号应为 06。

## 安装

建议安装到独立测试目录，不要覆盖现场数据。

```bash
chmod +x install_fixture.sh
./install_fixture.sh /home/cat/.local/share/capture_system_all_features_test
```

在 `config/network/web.env` 中临时设置

```text
CAPTURE_DATA_ROOT=/home/cat/.local/share/capture_system_all_features_test
CAPTURE_PDF_FONT_PATH=/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf
```

PDF 需要 `reportlab` 和中文字体。设备缺少字体时执行

```bash
sudo apt-get install fonts-arphic-gbsn00lp
```

停止并重新启动 Web 后端，然后刷新浏览器。测试结束后恢复原 `CAPTURE_DATA_ROOT`。

## 前端检查顺序

1. 采集首页应显示 5 个任务，创建新任务后出现任务 06。
2. 数据回放选择任务 02，检查完整曲线、三段断线、缩放、平移、复位、悬停、统计、入口和出口 RTK。
3. 数据回放选择任务 03，检查右车道和另一组曲线。
4. 数据回放选择任务 04，检查异常中断、出口 RTK 未记录和不能正式导出。
5. 在数据回放删除任务 01，确认二次确认和三个页面同步移除。
6. 报告导出选择任务 02 或 03，TXT 按钮应可用。
7. PDF 区域应显示可汇总任务 2/5，生成的 PDF 应包含任务 02 和 03。
8. 任务 01、04、05 的 TXT 按钮应保持禁用并显示具体原因。

## 文件结构

```text
data/
├── capture.db
├── TEST_FIXTURE_DO_NOT_USE_FOR_FIELD_REPORTS.txt
└── tasks/
    ├── 10000000-...-0002/measurements.db
    ├── 10000000-...-0003/measurements.db
    └── 10000000-...-0004/measurements.db
```

`reference_outputs` 保存本次验证生成的参考 TXT 和 PDF，不会被安装脚本复制到运行数据目录。

## 验证

只检查数据库结构和统计

```bash
python verify_fixture.py data
```

使用当前后端完整验证 API、回放、创建、删除和导出。该脚本使用临时副本，不修改原测试数据。

```bash
python validate_with_backend.py /path/to/capture_system-main
```
