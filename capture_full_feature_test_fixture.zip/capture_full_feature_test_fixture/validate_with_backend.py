#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=Path, help="当前完整项目根目录")
    parser.add_argument("--fixture-root", type=Path, default=Path(__file__).resolve().parent / "data")
    parser.add_argument("--pdf-font", type=Path, default=Path("/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf"))
    args = parser.parse_args()

    project_root = args.project_root.resolve()
    sys.path.insert(0, str(project_root))
    from fastapi.testclient import TestClient
    from backend.main import create_app

    if not args.pdf_font.is_file():
        raise RuntimeError(f"PDF中文字体不存在：{args.pdf_font}")

    with tempfile.TemporaryDirectory(prefix="capture-fixture-api-") as temporary:
        runtime = Path(temporary) / "runtime"
        shutil.copytree(args.fixture_root.resolve(), runtime)
        site = Path(temporary) / "site"
        site.mkdir()
        (site / "index.html").write_text("<!doctype html><html><body>fixture</body></html>", encoding="utf-8")
        app = create_app(site, data_root=runtime, pdf_font_path=args.pdf_font, start_ros_bridge=False)
        result: dict[str, object] = {}
        with TestClient(app) as client:
            tasks = client.get("/api/v1/tasks")
            tasks.raise_for_status()
            task_rows = tasks.json()
            ids = {row["sequence"]: row["task_id"] for row in task_rows}
            result["task_count"] = len(task_rows)
            result["history_status"] = {
                str(seq): client.get(f"/api/v1/tasks/{ids[seq]}/measurements").status_code
                for seq in (2, 3, 4)
            }
            preview = client.get("/api/v1/reports/clearance-summary/preview")
            preview.raise_for_status()
            result["exportable_task_count"] = preview.json()["exportable_task_count"]
            txt = client.post(f"/api/v1/tasks/{ids[2]}/exports/txt")
            txt.raise_for_status()
            txt_download = client.get(txt.json()["download_url"])
            txt_download.raise_for_status()
            result["txt_bytes"] = len(txt_download.content)
            pdf = client.post("/api/v1/reports/clearance-summary")
            pdf.raise_for_status()
            pdf_download = client.get(pdf.json()["download_url"])
            pdf_download.raise_for_status()
            result["pdf_bytes"] = len(pdf_download.content)
            result["pdf_included_task_count"] = pdf.json()["included_task_count"]
            create = client.post("/api/v1/tasks", json={"tunnel_code": "TEST-CREATED-006", "tunnel_name": "前端创建测试（模拟）"})
            create.raise_for_status()
            result["created_sequence"] = create.json()["sequence"]
            delete = client.delete(f"/api/v1/tasks/{ids[1]}")
            result["delete_status"] = delete.status_code
        print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
