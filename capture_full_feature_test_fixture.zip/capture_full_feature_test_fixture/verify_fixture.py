#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

EXPECTED = {
    1: ("TEST-PENDING-001", "pending", 0, 0, False),
    2: ("TEST-EXPORT-L", "completed", 3000, 2885, True),
    3: ("TEST-EXPORT-R", "completed", 2400, 2305, True),
    4: ("TEST-INTERRUPTED", "interrupted", 1200, 1090, False),
    5: ("TEST-FAILED-001", "failed", 0, 0, False),
}


def check_database(path: Path) -> None:
    if not path.is_file():
        raise RuntimeError(f"文件不存在：{path}")
    with sqlite3.connect(path) as connection:
        result = connection.execute("PRAGMA integrity_check").fetchone()[0]
        if result != "ok":
            raise RuntimeError(f"数据库完整性检查失败：{path}：{result}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("data_root", nargs="?", type=Path, default=Path(__file__).resolve().parent / "data")
    args = parser.parse_args()
    root = args.data_root.resolve()
    check_database(root / "capture.db")

    with sqlite3.connect(root / "capture.db") as connection:
        connection.row_factory = sqlite3.Row
        version = connection.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0]
        if version != 2:
            raise RuntimeError(f"任务数据库版本应为2，实际为{version}")
        rows = connection.execute(
            "SELECT * FROM tasks WHERE deleted_at IS NULL ORDER BY sequence"
        ).fetchall()
        if len(rows) != 5:
            raise RuntimeError(f"可见任务应为5个，实际为{len(rows)}")

        for row in rows:
            seq = int(row["sequence"])
            expected = EXPECTED.get(seq)
            if expected is None:
                raise RuntimeError(f"出现未预期任务序号：{seq}")
            code, status, expected_total, expected_valid, expected_exportable = expected
            if row["tunnel_code"] != code or row["status"] != status:
                raise RuntimeError(f"任务{seq:02d}索引字段不符合预期")
            total = valid = 0
            complete = False
            origin = None
            if row["has_measurements"]:
                db_path = root / "tasks" / row["recording_path"]
                check_database(db_path)
                with sqlite3.connect(db_path) as measurement:
                    measurement.row_factory = sqlite3.Row
                    metadata = measurement.execute("SELECT * FROM recording_metadata WHERE id=1").fetchone()
                    if metadata is None or metadata["task_id"] != row["task_id"]:
                        raise RuntimeError(f"任务{seq:02d}测量元数据不匹配")
                    origin = metadata["data_origin"]
                    complete = bool(metadata["complete"])
                    aggregate = measurement.execute(
                        """
                        SELECT COUNT(*) total,
                               SUM(CASE WHEN valid=1 AND clearance_height_m IS NOT NULL THEN 1 ELSE 0 END) valid
                        FROM clearance_samples
                        """
                    ).fetchone()
                    total = int(aggregate["total"])
                    valid = int(aggregate["valid"] or 0)
            if total != expected_total or valid != expected_valid:
                raise RuntimeError(
                    f"任务{seq:02d}样本统计不符：total={total}, valid={valid}"
                )
            exportable = status == "completed" and origin == "recorded" and complete and valid > 0
            if exportable != expected_exportable:
                raise RuntimeError(f"任务{seq:02d}导出条件判断不符合预期")

    marker = root / "TEST_FIXTURE_DO_NOT_USE_FOR_FIELD_REPORTS.txt"
    if not marker.is_file():
        raise RuntimeError("缺少测试数据警示文件")

    print("验证通过")
    print(f"数据目录：{root}")
    print("任务数量：5")
    print("可导出任务：2")
    print("回放记录任务：3")
    print("任务02样本：3000，其中有效2885")
    print("任务03样本：2400，其中有效2305")
    print("任务04样本：1200，其中有效1090，异常中断")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"验证失败：{error}", file=sys.stderr)
        raise SystemExit(1)
