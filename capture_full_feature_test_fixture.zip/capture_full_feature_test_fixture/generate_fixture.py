#!/usr/bin/env python3
"""生成 Capture System 全功能前端测试数据。

注意：为了验证当前正式导出条件，可导出任务的 data_origin 使用 recorded。
所有任务编号、隧道名称和版本字段均明确标记为测试或模拟，不得用于现场报告。
"""
from __future__ import annotations

import argparse
import math
import shutil
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

TASK_PENDING = "10000000-0000-4000-8000-000000000001"
TASK_LEFT = "10000000-0000-4000-8000-000000000002"
TASK_RIGHT = "10000000-0000-4000-8000-000000000003"
TASK_INTERRUPTED = "10000000-0000-4000-8000-000000000004"
TASK_FAILED = "10000000-0000-4000-8000-000000000005"


def iso_utc(epoch_ns: int) -> str:
    return datetime.fromtimestamp(epoch_ns / 1_000_000_000, tz=timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def create_task_index(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.executescript(
            """
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL
            );
            CREATE TABLE tasks (
                task_id TEXT PRIMARY KEY,
                sequence INTEGER NOT NULL UNIQUE CHECK (sequence > 0),
                tunnel_code TEXT NOT NULL CHECK (length(tunnel_code) BETWEEN 1 AND 128),
                tunnel_name TEXT NOT NULL CHECK (length(tunnel_name) BETWEEN 1 AND 256),
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'running', 'paused', 'completed', 'interrupted', 'failed')),
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                started_at TEXT,
                completed_at TEXT,
                has_measurements INTEGER NOT NULL DEFAULT 0 CHECK (has_measurements IN (0, 1)),
                recording_path TEXT,
                schema_version INTEGER NOT NULL DEFAULT 1 CHECK (schema_version > 0),
                deleted_at TEXT,
                delete_reason TEXT
            );
            CREATE TABLE task_idempotency (
                idempotency_key TEXT PRIMARY KEY,
                request_hash TEXT NOT NULL,
                response_task_ids TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX tasks_status_sequence_idx ON tasks(status, sequence);
            CREATE INDEX tasks_measurements_sequence_idx ON tasks(has_measurements, sequence);
            CREATE INDEX tasks_deleted_sequence_idx ON tasks(deleted_at, sequence);
            """
        )
        connection.executemany(
            "INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            [(1, "2026-08-06T14:00:00Z"), (2, "2026-08-06T14:00:01Z")],
        )


def create_recording_schema(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        CREATE TABLE recording_metadata (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            schema_version INTEGER NOT NULL CHECK (schema_version > 0),
            task_id TEXT NOT NULL,
            data_origin TEXT NOT NULL CHECK (data_origin IN ('recorded', 'test_fixture')),
            lane TEXT NOT NULL CHECK (lane IN ('left', 'right', 'unknown')),
            started_at TEXT NOT NULL,
            ended_at TEXT,
            complete INTEGER NOT NULL CHECK (complete IN (0, 1)),
            nominal_sample_rate_hz REAL NOT NULL CHECK (nominal_sample_rate_hz > 0),
            algorithm_version TEXT,
            config_version TEXT,
            software_version TEXT
        );
        CREATE TABLE clearance_samples (
            sample_index INTEGER PRIMARY KEY CHECK (sample_index >= 0),
            source_timestamp_ns INTEGER NOT NULL,
            recorded_timestamp_ns INTEGER NOT NULL,
            elapsed_ms REAL NOT NULL CHECK (elapsed_ms >= 0),
            lidar_to_top_m REAL,
            clearance_height_m REAL,
            valid INTEGER NOT NULL CHECK (valid IN (0, 1)),
            invalid_reason TEXT,
            quality_score REAL
        );
        CREATE INDEX clearance_samples_timestamp_idx ON clearance_samples(source_timestamp_ns);
        CREATE TABLE rtk_endpoints (
            role TEXT PRIMARY KEY CHECK (role IN ('entry', 'exit')),
            timestamp_ns INTEGER NOT NULL,
            latitude_deg REAL NOT NULL,
            longitude_deg REAL NOT NULL,
            altitude_m REAL,
            fix_type TEXT NOT NULL,
            valid INTEGER NOT NULL CHECK (valid IN (0, 1))
        );
        CREATE TABLE pause_intervals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_elapsed_ms REAL NOT NULL,
            ended_elapsed_ms REAL NOT NULL,
            CHECK (ended_elapsed_ms >= started_elapsed_ms)
        );
        """
    )


def in_ranges(index: int, ranges: list[tuple[int, int, str]]) -> str | None:
    for start, end, reason in ranges:
        if start <= index < end:
            return reason
    return None


def create_recording(
    path: Path,
    *,
    task_id: str,
    start_ns: int,
    sample_count: int,
    lane: str,
    complete: bool,
    invalid_ranges: list[tuple[int, int, str]],
    pause_intervals: list[tuple[float, float]],
    entry: tuple[float, float, float],
    exit_: tuple[float, float, float] | None,
    base_height: float,
    dip_center_s: float,
    dip_depth: float,
    phase: float,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    end_ns = start_ns + (sample_count - 1) * 20_000_000
    with sqlite3.connect(path) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        create_recording_schema(connection)
        connection.execute(
            """
            INSERT INTO recording_metadata (
                id, schema_version, task_id, data_origin, lane, started_at,
                ended_at, complete, nominal_sample_rate_hz, algorithm_version,
                config_version, software_version
            ) VALUES (1, 1, ?, 'recorded', ?, ?, ?, ?, 50.0, ?, ?, ?)
            """,
            (
                task_id,
                lane,
                iso_utc(start_ns),
                iso_utc(end_ns) if complete else None,
                1 if complete else 0,
                "TEST-SIMULATED-clearance-1.0",
                "TEST-SIMULATED-config-1",
                "0.2.0-EXPORT-FIXTURE-NOT-FIELD-DATA",
            ),
        )

        batch: list[tuple[object, ...]] = []
        for index in range(sample_count):
            elapsed_ms = index * 20.0
            timestamp_ns = start_ns + index * 20_000_000
            reason = in_ranges(index, invalid_ranges)
            if reason is not None:
                batch.append((index, timestamp_ns, timestamp_ns + 1_600_000, elapsed_ms, None, None, 0, reason, None))
            else:
                seconds = index / 50.0
                broad = base_height + 0.055 * math.sin(seconds * 0.55 + phase) + 0.023 * math.sin(seconds * 1.85 + phase / 2)
                dip = dip_depth * math.exp(-((seconds - dip_center_s) ** 2) / 3.8)
                local_ripple = 0.008 * math.sin(seconds * 5.2)
                height = broad - dip + local_ripple
                lidar_to_top = height - 2.30
                quality = 0.90 + 0.075 * (0.5 + 0.5 * math.sin(seconds * 0.28 + phase))
                batch.append((
                    index,
                    timestamp_ns,
                    timestamp_ns + 1_600_000,
                    elapsed_ms,
                    round(lidar_to_top, 6),
                    round(height, 6),
                    1,
                    None,
                    round(quality, 4),
                ))
            if len(batch) >= 500:
                connection.executemany(
                    "INSERT INTO clearance_samples VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    batch,
                )
                batch.clear()
        if batch:
            connection.executemany(
                "INSERT INTO clearance_samples VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                batch,
            )

        connection.execute(
            "INSERT INTO rtk_endpoints VALUES ('entry', ?, ?, ?, ?, 'RTK_FIXED', 1)",
            (start_ns, *entry),
        )
        if exit_ is not None:
            connection.execute(
                "INSERT INTO rtk_endpoints VALUES ('exit', ?, ?, ?, ?, 'RTK_FIXED', 1)",
                (end_ns, *exit_),
            )
        connection.executemany(
            "INSERT INTO pause_intervals(started_elapsed_ms, ended_elapsed_ms) VALUES (?, ?)",
            pause_intervals,
        )
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def generate(output: Path, force: bool) -> None:
    if output.exists():
        if not force:
            raise SystemExit(f"输出目录已存在：{output}。使用 --force 覆盖。")
        shutil.rmtree(output)
    (output / "tasks").mkdir(parents=True)
    create_task_index(output / "capture.db")

    start_left = 1_785_978_000_000_000_000
    start_right = 1_785_981_900_000_000_000
    start_interrupted = 1_785_985_800_000_000_000

    left_rel = f"{TASK_LEFT}/measurements.db"
    right_rel = f"{TASK_RIGHT}/measurements.db"
    interrupted_rel = f"{TASK_INTERRUPTED}/measurements.db"

    create_recording(
        output / "tasks" / left_rel,
        task_id=TASK_LEFT,
        start_ns=start_left,
        sample_count=3000,
        lane="left",
        complete=True,
        invalid_ranges=[
            (380, 420, "insufficient_points"),
            (1320, 1360, "pose_coverage_below_threshold"),
            (2410, 2445, "candidate_plane_not_found"),
        ],
        pause_intervals=[(31_000.0, 33_200.0)],
        entry=(39.9000000, 116.3900000, 48.20),
        exit_=(39.9005200, 116.3911800, 48.62),
        base_height=5.24,
        dip_center_s=24.0,
        dip_depth=0.255,
        phase=0.2,
    )
    create_recording(
        output / "tasks" / right_rel,
        task_id=TASK_RIGHT,
        start_ns=start_right,
        sample_count=2400,
        lane="right",
        complete=True,
        invalid_ranges=[
            (220, 250, "insufficient_points"),
            (800, 835, "motion_compensation_unavailable"),
            (1770, 1800, "candidate_plane_not_found"),
        ],
        pause_intervals=[],
        entry=(31.2304000, 121.4737000, 12.80),
        exit_=(31.2309200, 121.4748600, 13.05),
        base_height=5.36,
        dip_center_s=17.0,
        dip_depth=0.185,
        phase=1.1,
    )
    create_recording(
        output / "tasks" / interrupted_rel,
        task_id=TASK_INTERRUPTED,
        start_ns=start_interrupted,
        sample_count=1200,
        lane="left",
        complete=False,
        invalid_ranges=[
            (150, 190, "insufficient_points"),
            (760, 830, "rtk_or_pose_timeout"),
        ],
        pause_intervals=[(12_000.0, 13_400.0)],
        entry=(30.5728000, 104.0668000, 502.10),
        exit_=None,
        base_height=5.18,
        dip_center_s=13.0,
        dip_depth=0.16,
        phase=2.2,
    )

    left_end = start_left + (3000 - 1) * 20_000_000
    right_end = start_right + (2400 - 1) * 20_000_000
    interrupted_last = start_interrupted + (1200 - 1) * 20_000_000
    with sqlite3.connect(output / "capture.db") as connection:
        connection.executemany(
            """
            INSERT INTO tasks (
                task_id, sequence, tunnel_code, tunnel_name, status,
                created_at, updated_at, started_at, completed_at,
                has_measurements, recording_path, schema_version,
                deleted_at, delete_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 2, NULL, NULL)
            """,
            [
                (
                    TASK_PENDING, 1, "TEST-PENDING-001", "待执行任务测试（模拟）", "pending",
                    "2026-08-06T13:50:00Z", "2026-08-06T13:50:00Z", None, None, 0, None,
                ),
                (
                    TASK_LEFT, 2, "TEST-EXPORT-L", "左车道完整记录测试（模拟）", "completed",
                    "2026-08-06T13:55:00Z", iso_utc(left_end), iso_utc(start_left), iso_utc(left_end), 1, left_rel,
                ),
                (
                    TASK_RIGHT, 3, "TEST-EXPORT-R", "右车道完整记录测试（模拟）", "completed",
                    "2026-08-06T14:55:00Z", iso_utc(right_end), iso_utc(start_right), iso_utc(right_end), 1, right_rel,
                ),
                (
                    TASK_INTERRUPTED, 4, "TEST-INTERRUPTED", "异常中断记录测试（模拟）", "interrupted",
                    "2026-08-06T15:55:00Z", iso_utc(interrupted_last), iso_utc(start_interrupted), None, 1, interrupted_rel,
                ),
                (
                    TASK_FAILED, 5, "TEST-FAILED-001", "失败状态任务测试（模拟）", "failed",
                    "2026-08-06T16:55:00Z", "2026-08-06T16:56:00Z", "2026-08-06T16:55:30Z", None, 0, None,
                ),
            ],
        )
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"

    (output / "TEST_FIXTURE_DO_NOT_USE_FOR_FIELD_REPORTS.txt").write_text(
        "本目录仅用于前端和导出功能测试。所有高度、坐标、状态和时间均为模拟数据。\n"
        "为通过当前正式导出条件，任务 02 和 03 的 data_origin 字段设置为 recorded。\n"
        "生成的 TXT 和 PDF 不得作为现场检测记录或正式报告。\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    generate(args.output.resolve(), args.force)


if __name__ == "__main__":
    main()
