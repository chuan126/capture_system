#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
SOURCE_DIR="$SCRIPT_DIR/data"
TARGET_DIR="${1:-}"
FORCE="${2:-}"

if [[ -z "$TARGET_DIR" ]]; then
  echo "用法：$0 <独立测试数据目录> [--force]" >&2
  echo "示例：$0 /home/cat/.local/share/capture_system_all_features_test" >&2
  exit 2
fi

TARGET_DIR=$(python - "$TARGET_DIR" <<'PY'
from pathlib import Path
import sys
print(Path(sys.argv[1]).expanduser().resolve())
PY
)

if [[ -e "$TARGET_DIR" ]] && [[ -n "$(find "$TARGET_DIR" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  if [[ "$FORCE" != "--force" ]]; then
    echo "目标目录非空，未覆盖：$TARGET_DIR" >&2
    echo "确认是测试目录后，可增加 --force。原目录将先备份。" >&2
    exit 3
  fi
  BACKUP_DIR="${TARGET_DIR}.backup.$(date +%Y%m%d_%H%M%S)"
  mv "$TARGET_DIR" "$BACKUP_DIR"
  echo "原目录已备份到：$BACKUP_DIR"
fi

mkdir -p "$TARGET_DIR"
cp -a "$SOURCE_DIR"/. "$TARGET_DIR"/
python "$SCRIPT_DIR/verify_fixture.py" "$TARGET_DIR"

echo
echo "安装完成。请在停止 Web 后端后设置："
echo "CAPTURE_DATA_ROOT=$TARGET_DIR"
echo "CAPTURE_PDF_FONT_PATH=/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf"
echo "然后重新启动 Web 后端并刷新浏览器。"
